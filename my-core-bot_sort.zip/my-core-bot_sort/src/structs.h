struct t_game_data
{
	int	workers_amount;
	int	warriors_amount;
	int	wave_workers;
};

typedef struct t_game_data t_game_data;