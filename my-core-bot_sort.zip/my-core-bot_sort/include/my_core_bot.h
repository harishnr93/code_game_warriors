#ifndef MY_CORE_BOT_H
#define MY_CORE_BOT_H

#include "/core/con_lib.h"
#include <stdio.h>

// your defines here

#endif